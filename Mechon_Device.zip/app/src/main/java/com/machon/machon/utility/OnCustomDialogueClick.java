package com.machon.machon.utility;

public interface OnCustomDialogueClick {
    void onDialogueClick(EnumClicks where, String data);
}
