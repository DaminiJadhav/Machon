package com.machon.machon.utility;

import android.view.View;

public interface OnRecyclerViewClick {
    void onReclerViewClick(View view , int position);
}
