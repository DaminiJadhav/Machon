package com.machon.machon.utility;

public enum EnumClicks {
    RESENDOTP,
    VERIFYOTP
}
