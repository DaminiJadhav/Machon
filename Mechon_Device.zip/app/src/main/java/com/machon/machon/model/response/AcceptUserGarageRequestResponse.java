package com.machon.machon.model.response;

public class AcceptUserGarageRequestResponse {
}
