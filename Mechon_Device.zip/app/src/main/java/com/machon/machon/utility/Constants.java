package com.machon.machon.utility;

public class Constants {


    public static final int SELECTEDCHECKBOXCODE = 2;
    public static final String  ISSUE_SELECTED_LIST= "ISSUE_SELLECTED_LIST";
    public static final String  ISSUE_ID= "ISSUE_SELLECTED_ID";
    public static final String  OTHER_ISSUE_TEXT= "OTHERISSUETEXT";


    public static final int GARAGELOCATIONSELECTION = 3;
    public static final String SELECTED_GARARAGE_LOC = "SELECTED_GARAGE_LOCATION";
    public static final String GARAGE_LOCATION_KEY = "GARAGE_LOCATION";
    public static final String SELECTED_LATITUDE = "SELECTED_LATITUDE";
    public static final String SELECTED_LONGITUDE = "SELECTED_LONGITUDE";

    public static final int SELECTEDGARAGETYPECODE = 4;
    public static final String  SELECTED_GARAGE_TYPE_LIST= "SELECTED_GARAGE_TYPES";
    public static final String GARAGE_ISSUE_RESPONSE = "GARAGE_LIST";


    public static final String USERMOBILENUMBER = "USER_MOBILE_NUMBER";
    public static final String MECHANICMOBILENUMBER = "MECHANIC_MOBILE_NUMBER";

    public static final String FORGETPASSWORD = "FORGET_PASSWORD";



    public static final int PLACE_PICKUP_POINT = 11;


    //notification

    public static final String ANDROID_CHANNEL_ID = "MECHON_CHANNEL_ID";
    public static final String ANDROID_CHANNEL_NAME = "CUSTOMER_ID";


    public static final String PUSH_TITLE = "title";
    public static final String PUSH_ACTION = "action";
    public static final String PUSH_TYPE = "type";
    public static final String PUSH_ORDER_ID="orderId";
    public static final String PUSH_COMPANY_ID="companyId";






}
